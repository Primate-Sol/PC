import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";

const stageColors = {
  prospecting: "bg-blue-500",
  qualification: "bg-green-500",
  proposal: "bg-yellow-500",
  negotiation: "bg-blue-500",
  "closed-won": "bg-green-500",
};

const stageNames = {
  prospecting: "Prospecting",
  qualification: "Qualification",
  proposal: "Proposal",
  negotiation: "Negotiation",
  "closed-won": "Closed Won",
};

export default function SalesPipeline() {
  const { data: pipelineData = [], isLoading, refetch } = useQuery({
    queryKey: ["/api/dashboard/pipeline"],
  });

  const handleRefresh = () => {
    refetch();
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Sales Pipeline</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-gray-200 rounded-full"></div>
                    <div className="h-4 bg-gray-200 rounded w-24"></div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="h-4 bg-gray-200 rounded w-16"></div>
                    <div className="h-4 bg-gray-200 rounded w-20"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Sales Pipeline</CardTitle>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={handleRefresh}
            className="text-primary hover:text-blue-700"
          >
            <RefreshCw className="h-4 w-4 mr-1" />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {pipelineData.map((stage: any) => (
            <div key={stage.stage} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div 
                  className={`w-3 h-3 rounded-full ${
                    stageColors[stage.stage as keyof typeof stageColors] || "bg-gray-400"
                  }`}
                ></div>
                <span className="font-medium text-gray-800">
                  {stageNames[stage.stage as keyof typeof stageNames] || stage.stage}
                </span>
              </div>
              <div className="flex items-center space-x-4">
                <span className="text-sm text-gray-600">
                  {stage.count} deal{stage.count !== 1 ? 's' : ''}
                </span>
                <span className="font-semibold text-gray-800">
                  ${stage.value.toLocaleString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
