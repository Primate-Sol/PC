import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3, Users, Handshake, TrendingUp, Shield, Zap } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center">
              <BarChart3 className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-5xl font-bold text-gray-900 mb-4">CRM Pro</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Streamline your customer relationships, boost sales, and grow your business with our comprehensive CRM solution.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <Card className="text-center">
            <CardHeader>
              <Users className="w-12 h-12 text-primary mx-auto mb-4" />
              <CardTitle>Customer Management</CardTitle>
              <CardDescription>
                Organize and track all your customer information in one centralized location
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Handshake className="w-12 h-12 text-primary mx-auto mb-4" />
              <CardTitle>Deal Pipeline</CardTitle>
              <CardDescription>
                Track deals through your sales process with visual pipeline management
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <TrendingUp className="w-12 h-12 text-primary mx-auto mb-4" />
              <CardTitle>Analytics & Reports</CardTitle>
              <CardDescription>
                Get insights into your sales performance with detailed analytics
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Shield className="w-12 h-12 text-primary mx-auto mb-4" />
              <CardTitle>Secure & Reliable</CardTitle>
              <CardDescription>
                Enterprise-grade security with reliable data protection
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Zap className="w-12 h-12 text-primary mx-auto mb-4" />
              <CardTitle>Fast & Efficient</CardTitle>
              <CardDescription>
                Streamlined workflows to help you work more efficiently
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <BarChart3 className="w-12 h-12 text-primary mx-auto mb-4" />
              <CardTitle>Professional Interface</CardTitle>
              <CardDescription>
                Clean, intuitive design that makes managing your CRM a pleasure
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* CTA Section */}
        <Card className="max-w-2xl mx-auto text-center">
          <CardHeader>
            <CardTitle className="text-3xl">Ready to get started?</CardTitle>
            <CardDescription className="text-lg">
              Join thousands of businesses already using CRM Pro to manage their customer relationships.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <Button 
              onClick={handleLogin}
              size="lg" 
              className="text-lg px-8 py-3"
            >
              Sign In to Get Started
            </Button>
            <p className="text-sm text-gray-500 mt-4">
              Secure authentication powered by Replit
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
