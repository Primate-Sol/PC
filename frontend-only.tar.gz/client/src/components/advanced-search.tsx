import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Search, Filter, X, Calendar as CalendarIcon, Save, Star } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface SearchFilter {
  field: string;
  operator: string;
  value: string;
  type: string;
}

interface AdvancedSearchProps {
  entityType: "customers" | "contacts" | "deals" | "activities";
  onSearchChange: (filters: SearchFilter[], sortBy?: string, sortOrder?: string) => void;
  savedSearches?: Array<{
    id: number;
    name: string;
    filters: SearchFilter[];
    sortBy?: string;
    sortOrder?: string;
    isDefault?: boolean;
  }>;
  onSaveSearch?: (name: string, filters: SearchFilter[], sortBy?: string, sortOrder?: string) => void;
}

const fieldOptions = {
  customers: [
    { value: "name", label: "Company Name", type: "text" },
    { value: "industry", label: "Industry", type: "select" },
    { value: "size", label: "Company Size", type: "select" },
    { value: "revenue", label: "Revenue", type: "number" },
    { value: "createdAt", label: "Created Date", type: "date" },
    { value: "updatedAt", label: "Last Updated", type: "date" },
  ],
  contacts: [
    { value: "firstName", label: "First Name", type: "text" },
    { value: "lastName", label: "Last Name", type: "text" },
    { value: "email", label: "Email", type: "text" },
    { value: "phone", label: "Phone", type: "text" },
    { value: "position", label: "Position", type: "text" },
    { value: "createdAt", label: "Created Date", type: "date" },
  ],
  deals: [
    { value: "title", label: "Deal Title", type: "text" },
    { value: "value", label: "Deal Value", type: "number" },
    { value: "stage", label: "Stage", type: "select" },
    { value: "probability", label: "Probability", type: "number" },
    { value: "expectedCloseDate", label: "Expected Close Date", type: "date" },
    { value: "createdAt", label: "Created Date", type: "date" },
  ],
  activities: [
    { value: "type", label: "Activity Type", type: "select" },
    { value: "description", label: "Description", type: "text" },
    { value: "entityType", label: "Related To", type: "select" },
    { value: "createdAt", label: "Date", type: "date" },
  ],
};

const operatorOptions = {
  text: [
    { value: "contains", label: "Contains" },
    { value: "equals", label: "Equals" },
    { value: "startsWith", label: "Starts with" },
    { value: "endsWith", label: "Ends with" },
    { value: "notContains", label: "Does not contain" },
  ],
  number: [
    { value: "equals", label: "Equals" },
    { value: "greaterThan", label: "Greater than" },
    { value: "lessThan", label: "Less than" },
    { value: "between", label: "Between" },
  ],
  date: [
    { value: "equals", label: "On" },
    { value: "before", label: "Before" },
    { value: "after", label: "After" },
    { value: "between", label: "Between" },
    { value: "lastDays", label: "Last X days" },
  ],
  select: [
    { value: "equals", label: "Equals" },
    { value: "notEquals", label: "Not equals" },
    { value: "in", label: "In list" },
  ],
};

export default function AdvancedSearch({
  entityType,
  onSearchChange,
  savedSearches = [],
  onSaveSearch,
}: AdvancedSearchProps) {
  const [filters, setFilters] = useState<SearchFilter[]>([]);
  const [sortBy, setSortBy] = useState<string>("");
  const [sortOrder, setSortOrder] = useState<string>("asc");
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  const [isSaveDialogOpen, setIsSaveDialogOpen] = useState(false);
  const [searchName, setSearchName] = useState("");
  const [quickSearch, setQuickSearch] = useState("");

  const addFilter = () => {
    const newFilter: SearchFilter = {
      field: fieldOptions[entityType][0].value,
      operator: "contains",
      value: "",
      type: fieldOptions[entityType][0].type,
    };
    setFilters([...filters, newFilter]);
  };

  const updateFilter = (index: number, key: keyof SearchFilter, value: string) => {
    const newFilters = [...filters];
    newFilters[index] = { ...newFilters[index], [key]: value };

    // Update operator options when field changes
    if (key === "field") {
      const fieldOption = fieldOptions[entityType].find(f => f.value === value);
      if (fieldOption) {
        newFilters[index].type = fieldOption.type;
        newFilters[index].operator = operatorOptions[fieldOption.type as keyof typeof operatorOptions][0].value;
      }
    }

    setFilters(newFilters);
  };

  const removeFilter = (index: number) => {
    setFilters(filters.filter((_, i) => i !== index));
  };

  const applySearch = () => {
    const activeFilters = filters.filter(f => f.value.trim() !== "");
    
    // Add quick search as a filter if present
    if (quickSearch.trim()) {
      const quickFilter: SearchFilter = {
        field: "quickSearch",
        operator: "contains",
        value: quickSearch.trim(),
        type: "text",
      };
      activeFilters.unshift(quickFilter);
    }

    onSearchChange(activeFilters, sortBy, sortOrder);
    setIsFiltersOpen(false);
  };

  const clearFilters = () => {
    setFilters([]);
    setQuickSearch("");
    setSortBy("");
    setSortOrder("asc");
    onSearchChange([], "", "asc");
  };

  const loadSavedSearch = (search: any) => {
    setFilters(search.filters);
    setSortBy(search.sortBy || "");
    setSortOrder(search.sortOrder || "asc");
    onSearchChange(search.filters, search.sortBy, search.sortOrder);
  };

  const saveCurrentSearch = () => {
    if (onSaveSearch && searchName.trim()) {
      onSaveSearch(searchName.trim(), filters, sortBy, sortOrder);
      setSearchName("");
      setIsSaveDialogOpen(false);
    }
  };

  const getFieldType = (fieldValue: string) => {
    const field = fieldOptions[entityType].find(f => f.value === fieldValue);
    return field?.type || "text";
  };

  return (
    <Card className="mb-6">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Search & Filter</CardTitle>
          <div className="flex items-center space-x-2">
            {savedSearches.length > 0 && (
              <Select onValueChange={(value) => {
                const search = savedSearches.find(s => s.id.toString() === value);
                if (search) loadSavedSearch(search);
              }}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Saved searches" />
                </SelectTrigger>
                <SelectContent>
                  {savedSearches.map((search) => (
                    <SelectItem key={search.id} value={search.id.toString()}>
                      <div className="flex items-center">
                        {search.isDefault && <Star className="mr-2 h-3 w-3 fill-current" />}
                        {search.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            <Dialog open={isFiltersOpen} onOpenChange={setIsFiltersOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Filter className="mr-2 h-4 w-4" />
                  Advanced
                  {filters.length > 0 && (
                    <Badge variant="secondary" className="ml-2">
                      {filters.length}
                    </Badge>
                  )}
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Advanced Search</DialogTitle>
                  <DialogDescription>
                    Create complex filters to find exactly what you're looking for
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-6">
                  {/* Filters */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-medium">Filters</h3>
                      <Button size="sm" onClick={addFilter}>
                        Add Filter
                      </Button>
                    </div>
                    {filters.map((filter, index) => (
                      <div key={index} className="flex items-center space-x-2 p-3 border rounded-lg">
                        <Select
                          value={filter.field}
                          onValueChange={(value) => updateFilter(index, "field", value)}
                        >
                          <SelectTrigger className="w-[150px]">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {fieldOptions[entityType].map((field) => (
                              <SelectItem key={field.value} value={field.value}>
                                {field.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Select
                          value={filter.operator}
                          onValueChange={(value) => updateFilter(index, "operator", value)}
                        >
                          <SelectTrigger className="w-[120px]">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {operatorOptions[getFieldType(filter.field) as keyof typeof operatorOptions]?.map((op) => (
                              <SelectItem key={op.value} value={op.value}>
                                {op.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        {filter.type === "date" ? (
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                variant="outline"
                                className={cn(
                                  "w-[200px] justify-start text-left font-normal",
                                  !filter.value && "text-muted-foreground"
                                )}
                              >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {filter.value ? format(new Date(filter.value), "PPP") : "Pick a date"}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                              <Calendar
                                mode="single"
                                selected={filter.value ? new Date(filter.value) : undefined}
                                onSelect={(date) => updateFilter(index, "value", date?.toISOString() || "")}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                        ) : (
                          <Input
                            className="w-[200px]"
                            placeholder="Enter value"
                            value={filter.value}
                            onChange={(e) => updateFilter(index, "value", e.target.value)}
                            type={filter.type === "number" ? "number" : "text"}
                          />
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => removeFilter(index)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                    {filters.length === 0 && (
                      <div className="text-center py-8 text-muted-foreground">
                        No filters added. Click "Add Filter" to get started.
                      </div>
                    )}
                  </div>

                  <Separator />

                  {/* Sorting */}
                  <div className="space-y-4">
                    <h3 className="text-sm font-medium">Sorting</h3>
                    <div className="flex items-center space-x-2">
                      <Label className="w-20">Sort by:</Label>
                      <Select value={sortBy} onValueChange={setSortBy}>
                        <SelectTrigger className="w-[200px]">
                          <SelectValue placeholder="Select field" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">None</SelectItem>
                          {fieldOptions[entityType].map((field) => (
                            <SelectItem key={field.value} value={field.value}>
                              {field.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Select value={sortOrder} onValueChange={setSortOrder}>
                        <SelectTrigger className="w-[120px]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="asc">Ascending</SelectItem>
                          <SelectItem value="desc">Descending</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-between pt-4">
                    <div className="flex space-x-2">
                      <Button variant="outline" onClick={clearFilters}>
                        Clear All
                      </Button>
                      {onSaveSearch && (
                        <Dialog open={isSaveDialogOpen} onOpenChange={setIsSaveDialogOpen}>
                          <DialogTrigger asChild>
                            <Button variant="outline">
                              <Save className="mr-2 h-4 w-4" />
                              Save Search
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Save Search</DialogTitle>
                              <DialogDescription>
                                Give your search a name to save it for later use
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                              <Input
                                placeholder="Search name"
                                value={searchName}
                                onChange={(e) => setSearchName(e.target.value)}
                              />
                              <div className="flex justify-end space-x-2">
                                <Button
                                  variant="outline"
                                  onClick={() => setIsSaveDialogOpen(false)}
                                >
                                  Cancel
                                </Button>
                                <Button onClick={saveCurrentSearch}>
                                  Save
                                </Button>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                      )}
                    </div>
                    <Button onClick={applySearch}>
                      Apply Search
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center space-x-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder={`Search ${entityType}...`}
              value={quickSearch}
              onChange={(e) => setQuickSearch(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && applySearch()}
              className="pl-10"
            />
          </div>
          <Button onClick={applySearch}>
            Search
          </Button>
        </div>
        {(filters.length > 0 || sortBy) && (
          <div className="mt-4 flex flex-wrap gap-2">
            {filters.map((filter, index) => (
              <Badge key={index} variant="secondary" className="flex items-center gap-1">
                {fieldOptions[entityType].find(f => f.value === filter.field)?.label} {filter.operator} {filter.value}
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-4 w-4 p-0"
                  onClick={() => removeFilter(index)}
                >
                  <X className="h-3 w-3" />
                </Button>
              </Badge>
            ))}
            {sortBy && (
              <Badge variant="outline">
                Sort: {fieldOptions[entityType].find(f => f.value === sortBy)?.label} ({sortOrder})
              </Badge>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}