import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Users, Handshake, DollarSign, Percent, TrendingUp, TrendingDown } from "lucide-react";

export default function MetricsCards() {
  const { data: metrics, isLoading } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-24"></div>
                  <div className="h-8 bg-gray-200 rounded w-16"></div>
                  <div className="h-4 bg-gray-200 rounded w-32"></div>
                </div>
                <div className="w-12 h-12 bg-gray-200 rounded-lg"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!metrics) {
    return null;
  }

  const cards = [
    {
      title: "Total Customers",
      value: metrics.totalCustomers.toLocaleString(),
      growth: `${metrics.customerGrowth}% from last month`,
      icon: Users,
      iconColor: "text-primary",
      iconBg: "bg-blue-100",
      isPositive: metrics.customerGrowth > 0,
    },
    {
      title: "Active Deals",
      value: metrics.activeDeals.toString(),
      growth: `${metrics.dealGrowth}% from last month`,
      icon: Handshake,
      iconColor: "text-green-600",
      iconBg: "bg-green-100",
      isPositive: metrics.dealGrowth > 0,
    },
    {
      title: "Revenue",
      value: `$${metrics.totalRevenue.toLocaleString()}`,
      growth: `${metrics.revenueGrowth}% from last month`,
      icon: DollarSign,
      iconColor: "text-yellow-600",
      iconBg: "bg-yellow-100",
      isPositive: metrics.revenueGrowth > 0,
    },
    {
      title: "Conversion Rate",
      value: `${metrics.conversionRate.toFixed(1)}%`,
      growth: "Based on closed deals",
      icon: Percent,
      iconColor: "text-purple-600",
      iconBg: "bg-purple-100",
      isPositive: true,
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {cards.map((card, index) => {
        const Icon = card.icon;
        const TrendIcon = card.isPositive ? TrendingUp : TrendingDown;
        
        return (
          <Card key={index} className="border border-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">{card.title}</p>
                  <p className="text-3xl font-semibold text-gray-800">{card.value}</p>
                  <p className={`text-sm mt-2 flex items-center ${
                    card.isPositive ? 'text-green-600' : 'text-red-600'
                  }`}>
                    <TrendIcon className="h-4 w-4 mr-1" />
                    <span>{card.growth}</span>
                  </p>
                </div>
                <div className={`w-12 h-12 ${card.iconBg} rounded-lg flex items-center justify-center`}>
                  <Icon className={`${card.iconColor} text-xl`} />
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
