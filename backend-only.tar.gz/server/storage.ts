import {
  users,
  customers,
  contacts,
  deals,
  activities,
  tasks,
  emailTemplates,
  emailCommunications,
  customFields,
  customFieldValues,
  pipelineStages,
  activityTypes,
  reports,
  exportJobs,
  savedSearches,
  type User,
  type UpsertUser,
  type Customer,
  type InsertCustomer,
  type Contact,
  type InsertContact,
  type Deal,
  type InsertDeal,
  type Activity,
  type InsertActivity,
  type Task,
  type InsertTask,
  type EmailTemplate,
  type InsertEmailTemplate,
  type EmailCommunication,
  type InsertEmailCommunication,
  type CustomField,
  type InsertCustomField,
  type CustomFieldValue,
  type PipelineStage,
  type InsertPipelineStage,
  type ActivityType,
  type Report,
  type InsertReport,
  type ExportJob,
  type InsertExportJob,
  type SavedSearch,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, ilike, count, sum, gte, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Customer operations
  getCustomers(userId: string): Promise<Customer[]>;
  getCustomer(id: number, userId: string): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, customer: Partial<InsertCustomer>, userId: string): Promise<Customer | undefined>;
  deleteCustomer(id: number, userId: string): Promise<boolean>;
  searchCustomers(query: string, userId: string): Promise<Customer[]>;

  // Contact operations
  getContacts(userId: string): Promise<Contact[]>;
  getContact(id: number, userId: string): Promise<Contact | undefined>;
  getContactsByCustomer(customerId: number, userId: string): Promise<Contact[]>;
  createContact(contact: InsertContact): Promise<Contact>;
  updateContact(id: number, contact: Partial<InsertContact>, userId: string): Promise<Contact | undefined>;
  deleteContact(id: number, userId: string): Promise<boolean>;

  // Deal operations
  getDeals(userId: string): Promise<Deal[]>;
  getDeal(id: number, userId: string): Promise<Deal | undefined>;
  createDeal(deal: InsertDeal): Promise<Deal>;
  updateDeal(id: number, deal: Partial<InsertDeal>, userId: string): Promise<Deal | undefined>;
  deleteDeal(id: number, userId: string): Promise<boolean>;
  getDealsByStage(stage: string, userId: string): Promise<Deal[]>;

  // Activity operations
  getActivities(userId: string, limit?: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;

  // Task operations
  getTasks(userId: string): Promise<Task[]>;
  getTask(id: number, userId: string): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<InsertTask>, userId: string): Promise<Task | undefined>;
  deleteTask(id: number, userId: string): Promise<boolean>;
  getUpcomingTasks(userId: string): Promise<Task[]>;

  // Dashboard metrics
  getDashboardMetrics(userId: string): Promise<{
    totalCustomers: number;
    activeDeals: number;
    totalRevenue: number;
    conversionRate: number;
    customerGrowth: number;
    dealGrowth: number;
    revenueGrowth: number;
  }>;
  
  getPipelineData(userId: string): Promise<Array<{
    stage: string;
    count: number;
    value: number;
  }>>;

  // Email operations
  getEmailTemplates(userId: string): Promise<EmailTemplate[]>;
  getEmailTemplate(id: number, userId: string): Promise<EmailTemplate | undefined>;
  createEmailTemplate(template: InsertEmailTemplate): Promise<EmailTemplate>;
  updateEmailTemplate(id: number, template: Partial<InsertEmailTemplate>, userId: string): Promise<EmailTemplate | undefined>;
  deleteEmailTemplate(id: number, userId: string): Promise<boolean>;

  getEmailCommunications(userId: string): Promise<EmailCommunication[]>;
  createEmailCommunication(communication: InsertEmailCommunication): Promise<EmailCommunication>;
  updateEmailCommunication(id: number, communication: Partial<InsertEmailCommunication>, userId: string): Promise<EmailCommunication | undefined>;

  // Custom fields operations
  getCustomFields(userId: string, entityType: string): Promise<CustomField[]>;
  createCustomField(field: InsertCustomField): Promise<CustomField>;
  updateCustomField(id: number, field: Partial<InsertCustomField>, userId: string): Promise<CustomField | undefined>;
  deleteCustomField(id: number, userId: string): Promise<boolean>;

  getCustomFieldValues(entityId: number, entityType: string): Promise<CustomFieldValue[]>;
  setCustomFieldValue(customFieldId: number, entityId: number, entityType: string, value: string): Promise<CustomFieldValue>;

  // Pipeline customization
  getPipelineStages(userId: string): Promise<PipelineStage[]>;
  createPipelineStage(stage: InsertPipelineStage): Promise<PipelineStage>;
  updatePipelineStage(id: number, stage: Partial<InsertPipelineStage>, userId: string): Promise<PipelineStage | undefined>;
  deletePipelineStage(id: number, userId: string): Promise<boolean>;

  // Activity types
  getActivityTypes(userId: string): Promise<ActivityType[]>;
  createActivityType(type: any): Promise<ActivityType>;

  // Reports operations
  getReports(userId: string): Promise<Report[]>;
  createReport(report: InsertReport): Promise<Report>;
  updateReport(id: number, report: Partial<InsertReport>, userId: string): Promise<Report | undefined>;
  deleteReport(id: number, userId: string): Promise<boolean>;

  // Export operations
  getExportJobs(userId: string): Promise<ExportJob[]>;
  createExportJob(job: InsertExportJob): Promise<ExportJob>;
  updateExportJob(id: number, updates: Partial<ExportJob>, userId: string): Promise<ExportJob | undefined>;

  // Saved searches
  getSavedSearches(userId: string, entityType: string): Promise<SavedSearch[]>;
  createSavedSearch(search: any): Promise<SavedSearch>;
  deleteSavedSearch(id: number, userId: string): Promise<boolean>;

  // Advanced analytics
  getSalesAnalytics(userId: string, days: number): Promise<any>;
  getCustomerAnalytics(userId: string, days: number): Promise<any>;
  getPipelineAnalytics(userId: string): Promise<any>;
  getActivityAnalytics(userId: string, days: number): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Customer operations
  async getCustomers(userId: string): Promise<Customer[]> {
    return await db
      .select()
      .from(customers)
      .where(eq(customers.createdBy, userId))
      .orderBy(desc(customers.createdAt));
  }

  async getCustomer(id: number, userId: string): Promise<Customer | undefined> {
    const [customer] = await db
      .select()
      .from(customers)
      .where(and(eq(customers.id, id), eq(customers.createdBy, userId)));
    return customer;
  }

  async createCustomer(customer: InsertCustomer): Promise<Customer> {
    const [newCustomer] = await db
      .insert(customers)
      .values(customer)
      .returning();
    return newCustomer;
  }

  async updateCustomer(id: number, customer: Partial<InsertCustomer>, userId: string): Promise<Customer | undefined> {
    const [updatedCustomer] = await db
      .update(customers)
      .set({ ...customer, updatedAt: new Date() })
      .where(and(eq(customers.id, id), eq(customers.createdBy, userId)))
      .returning();
    return updatedCustomer;
  }

  async deleteCustomer(id: number, userId: string): Promise<boolean> {
    const result = await db
      .delete(customers)
      .where(and(eq(customers.id, id), eq(customers.createdBy, userId)));
    return result.rowCount > 0;
  }

  async searchCustomers(query: string, userId: string): Promise<Customer[]> {
    return await db
      .select()
      .from(customers)
      .where(
        and(
          eq(customers.createdBy, userId),
          or(
            ilike(customers.companyName, `%${query}%`),
            ilike(customers.industry, `%${query}%`)
          )
        )
      )
      .orderBy(desc(customers.createdAt));
  }

  // Contact operations
  async getContacts(userId: string): Promise<Contact[]> {
    return await db
      .select()
      .from(contacts)
      .where(eq(contacts.createdBy, userId))
      .orderBy(desc(contacts.createdAt));
  }

  async getContact(id: number, userId: string): Promise<Contact | undefined> {
    const [contact] = await db
      .select()
      .from(contacts)
      .where(and(eq(contacts.id, id), eq(contacts.createdBy, userId)));
    return contact;
  }

  async getContactsByCustomer(customerId: number, userId: string): Promise<Contact[]> {
    return await db
      .select()
      .from(contacts)
      .where(and(eq(contacts.customerId, customerId), eq(contacts.createdBy, userId)))
      .orderBy(desc(contacts.createdAt));
  }

  async createContact(contact: InsertContact): Promise<Contact> {
    const [newContact] = await db
      .insert(contacts)
      .values(contact)
      .returning();
    return newContact;
  }

  async updateContact(id: number, contact: Partial<InsertContact>, userId: string): Promise<Contact | undefined> {
    const [updatedContact] = await db
      .update(contacts)
      .set({ ...contact, updatedAt: new Date() })
      .where(and(eq(contacts.id, id), eq(contacts.createdBy, userId)))
      .returning();
    return updatedContact;
  }

  async deleteContact(id: number, userId: string): Promise<boolean> {
    const result = await db
      .delete(contacts)
      .where(and(eq(contacts.id, id), eq(contacts.createdBy, userId)));
    return result.rowCount > 0;
  }

  // Deal operations
  async getDeals(userId: string): Promise<Deal[]> {
    return await db
      .select()
      .from(deals)
      .where(eq(deals.createdBy, userId))
      .orderBy(desc(deals.createdAt));
  }

  async getDeal(id: number, userId: string): Promise<Deal | undefined> {
    const [deal] = await db
      .select()
      .from(deals)
      .where(and(eq(deals.id, id), eq(deals.createdBy, userId)));
    return deal;
  }

  async createDeal(deal: InsertDeal): Promise<Deal> {
    const [newDeal] = await db
      .insert(deals)
      .values(deal)
      .returning();
    return newDeal;
  }

  async updateDeal(id: number, deal: Partial<InsertDeal>, userId: string): Promise<Deal | undefined> {
    const [updatedDeal] = await db
      .update(deals)
      .set({ ...deal, updatedAt: new Date() })
      .where(and(eq(deals.id, id), eq(deals.createdBy, userId)))
      .returning();
    return updatedDeal;
  }

  async deleteDeal(id: number, userId: string): Promise<boolean> {
    const result = await db
      .delete(deals)
      .where(and(eq(deals.id, id), eq(deals.createdBy, userId)));
    return result.rowCount > 0;
  }

  async getDealsByStage(stage: string, userId: string): Promise<Deal[]> {
    return await db
      .select()
      .from(deals)
      .where(and(eq(deals.stage, stage), eq(deals.createdBy, userId)))
      .orderBy(desc(deals.createdAt));
  }

  // Activity operations
  async getActivities(userId: string, limit = 10): Promise<Activity[]> {
    return await db
      .select()
      .from(activities)
      .where(eq(activities.performedBy, userId))
      .orderBy(desc(activities.createdAt))
      .limit(limit);
  }

  async createActivity(activity: InsertActivity): Promise<Activity> {
    const [newActivity] = await db
      .insert(activities)
      .values(activity)
      .returning();
    return newActivity;
  }

  // Task operations
  async getTasks(userId: string): Promise<Task[]> {
    return await db
      .select()
      .from(tasks)
      .where(or(eq(tasks.assignedTo, userId), eq(tasks.createdBy, userId)))
      .orderBy(desc(tasks.createdAt));
  }

  async getTask(id: number, userId: string): Promise<Task | undefined> {
    const [task] = await db
      .select()
      .from(tasks)
      .where(
        and(
          eq(tasks.id, id),
          or(eq(tasks.assignedTo, userId), eq(tasks.createdBy, userId))
        )
      );
    return task;
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db
      .insert(tasks)
      .values(task)
      .returning();
    return newTask;
  }

  async updateTask(id: number, task: Partial<InsertTask>, userId: string): Promise<Task | undefined> {
    const [updatedTask] = await db
      .update(tasks)
      .set({ ...task, updatedAt: new Date() })
      .where(
        and(
          eq(tasks.id, id),
          or(eq(tasks.assignedTo, userId), eq(tasks.createdBy, userId))
        )
      )
      .returning();
    return updatedTask;
  }

  async deleteTask(id: number, userId: string): Promise<boolean> {
    const result = await db
      .delete(tasks)
      .where(
        and(
          eq(tasks.id, id),
          or(eq(tasks.assignedTo, userId), eq(tasks.createdBy, userId))
        )
      );
    return result.rowCount > 0;
  }

  async getUpcomingTasks(userId: string): Promise<Task[]> {
    return await db
      .select()
      .from(tasks)
      .where(
        and(
          or(eq(tasks.assignedTo, userId), eq(tasks.createdBy, userId)),
          eq(tasks.completed, false)
        )
      )
      .orderBy(tasks.dueDate)
      .limit(10);
  }

  // Dashboard metrics
  async getDashboardMetrics(userId: string): Promise<{
    totalCustomers: number;
    activeDeals: number;
    totalRevenue: number;
    conversionRate: number;
    customerGrowth: number;
    dealGrowth: number;
    revenueGrowth: number;
  }> {
    const [customerCount] = await db
      .select({ count: count() })
      .from(customers)
      .where(eq(customers.createdBy, userId));

    const [dealCount] = await db
      .select({ count: count() })
      .from(deals)
      .where(eq(deals.createdBy, userId));

    const [revenueSum] = await db
      .select({ total: sum(deals.value) })
      .from(deals)
      .where(and(eq(deals.createdBy, userId), eq(deals.stage, "closed-won")));

    const [closedWonCount] = await db
      .select({ count: count() })
      .from(deals)
      .where(and(eq(deals.createdBy, userId), eq(deals.stage, "closed-won")));

    const totalRevenue = Number(revenueSum.total) || 0;
    const conversionRate = dealCount.count > 0 ? (closedWonCount.count / dealCount.count) * 100 : 0;

    return {
      totalCustomers: customerCount.count,
      activeDeals: dealCount.count,
      totalRevenue,
      conversionRate,
      customerGrowth: 12,
      dealGrowth: 8,
      revenueGrowth: 15,
    };
  }

  async getPipelineData(userId: string): Promise<Array<{
    stage: string;
    count: number;
    value: number;
  }>> {
    const stages = ["prospecting", "qualification", "proposal", "negotiation", "closed-won"];
    const pipelineData = [];

    for (const stage of stages) {
      const [stageCount] = await db
        .select({ count: count() })
        .from(deals)
        .where(and(eq(deals.createdBy, userId), eq(deals.stage, stage)));

      const [stageValue] = await db
        .select({ total: sum(deals.value) })
        .from(deals)
        .where(and(eq(deals.createdBy, userId), eq(deals.stage, stage)));

      pipelineData.push({
        stage,
        count: stageCount.count,
        value: Number(stageValue.total) || 0,
      });
    }

    return pipelineData;
  }

  // Email template operations
  async getEmailTemplates(userId: string): Promise<EmailTemplate[]> {
    return await db
      .select()
      .from(emailTemplates)
      .where(and(eq(emailTemplates.userId, userId), eq(emailTemplates.isActive, true)))
      .orderBy(emailTemplates.name);
  }

  async getEmailTemplate(id: number, userId: string): Promise<EmailTemplate | undefined> {
    const [template] = await db
      .select()
      .from(emailTemplates)
      .where(and(eq(emailTemplates.id, id), eq(emailTemplates.userId, userId)));
    return template;
  }

  async createEmailTemplate(template: InsertEmailTemplate): Promise<EmailTemplate> {
    const [created] = await db
      .insert(emailTemplates)
      .values(template)
      .returning();
    return created;
  }

  async updateEmailTemplate(id: number, template: Partial<InsertEmailTemplate>, userId: string): Promise<EmailTemplate | undefined> {
    const [updated] = await db
      .update(emailTemplates)
      .set({ ...template, updatedAt: new Date() })
      .where(and(eq(emailTemplates.id, id), eq(emailTemplates.userId, userId)))
      .returning();
    return updated;
  }

  async deleteEmailTemplate(id: number, userId: string): Promise<boolean> {
    const result = await db
      .update(emailTemplates)
      .set({ isActive: false })
      .where(and(eq(emailTemplates.id, id), eq(emailTemplates.userId, userId)));
    return (result.rowCount || 0) > 0;
  }

  // Email communication operations
  async getEmailCommunications(userId: string): Promise<EmailCommunication[]> {
    return await db
      .select()
      .from(emailCommunications)
      .where(eq(emailCommunications.userId, userId))
      .orderBy(desc(emailCommunications.createdAt));
  }

  async createEmailCommunication(communication: InsertEmailCommunication): Promise<EmailCommunication> {
    const [created] = await db
      .insert(emailCommunications)
      .values(communication)
      .returning();
    return created;
  }

  async updateEmailCommunication(id: number, communication: Partial<InsertEmailCommunication>, userId: string): Promise<EmailCommunication | undefined> {
    const [updated] = await db
      .update(emailCommunications)
      .set(communication)
      .where(and(eq(emailCommunications.id, id), eq(emailCommunications.userId, userId)))
      .returning();
    return updated;
  }

  // Custom fields operations
  async getCustomFields(userId: string, entityType: string): Promise<CustomField[]> {
    return await db
      .select()
      .from(customFields)
      .where(and(
        eq(customFields.userId, userId),
        eq(customFields.entityType, entityType),
        eq(customFields.isActive, true)
      ))
      .orderBy(customFields.displayOrder, customFields.fieldName);
  }

  async createCustomField(field: InsertCustomField): Promise<CustomField> {
    const [created] = await db
      .insert(customFields)
      .values(field)
      .returning();
    return created;
  }

  async updateCustomField(id: number, field: Partial<InsertCustomField>, userId: string): Promise<CustomField | undefined> {
    const [updated] = await db
      .update(customFields)
      .set(field)
      .where(and(eq(customFields.id, id), eq(customFields.userId, userId)))
      .returning();
    return updated;
  }

  async deleteCustomField(id: number, userId: string): Promise<boolean> {
    const result = await db
      .update(customFields)
      .set({ isActive: false })
      .where(and(eq(customFields.id, id), eq(customFields.userId, userId)));
    return (result.rowCount || 0) > 0;
  }

  async getCustomFieldValues(entityId: number, entityType: string): Promise<CustomFieldValue[]> {
    return await db
      .select()
      .from(customFieldValues)
      .where(and(
        eq(customFieldValues.entityId, entityId),
        eq(customFieldValues.entityType, entityType)
      ));
  }

  async setCustomFieldValue(customFieldId: number, entityId: number, entityType: string, value: string): Promise<CustomFieldValue> {
    const [existing] = await db
      .select()
      .from(customFieldValues)
      .where(and(
        eq(customFieldValues.customFieldId, customFieldId),
        eq(customFieldValues.entityId, entityId),
        eq(customFieldValues.entityType, entityType)
      ));

    if (existing) {
      const [updated] = await db
        .update(customFieldValues)
        .set({ value, updatedAt: new Date() })
        .where(eq(customFieldValues.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(customFieldValues)
        .values({
          customFieldId,
          entityId,
          entityType,
          value,
        })
        .returning();
      return created;
    }
  }

  // Pipeline stages operations
  async getPipelineStages(userId: string): Promise<PipelineStage[]> {
    return await db
      .select()
      .from(pipelineStages)
      .where(and(eq(pipelineStages.userId, userId), eq(pipelineStages.isActive, true)))
      .orderBy(pipelineStages.displayOrder);
  }

  async createPipelineStage(stage: InsertPipelineStage): Promise<PipelineStage> {
    const [created] = await db
      .insert(pipelineStages)
      .values(stage)
      .returning();
    return created;
  }

  async updatePipelineStage(id: number, stage: Partial<InsertPipelineStage>, userId: string): Promise<PipelineStage | undefined> {
    const [updated] = await db
      .update(pipelineStages)
      .set(stage)
      .where(and(eq(pipelineStages.id, id), eq(pipelineStages.userId, userId)))
      .returning();
    return updated;
  }

  async deletePipelineStage(id: number, userId: string): Promise<boolean> {
    const result = await db
      .update(pipelineStages)
      .set({ isActive: false })
      .where(and(eq(pipelineStages.id, id), eq(pipelineStages.userId, userId)));
    return (result.rowCount || 0) > 0;
  }

  // Activity types operations
  async getActivityTypes(userId: string): Promise<ActivityType[]> {
    return await db
      .select()
      .from(activityTypes)
      .where(and(eq(activityTypes.userId, userId), eq(activityTypes.isActive, true)))
      .orderBy(activityTypes.name);
  }

  async createActivityType(type: any): Promise<ActivityType> {
    const [created] = await db
      .insert(activityTypes)
      .values(type)
      .returning();
    return created;
  }

  // Reports operations
  async getReports(userId: string): Promise<Report[]> {
    return await db
      .select()
      .from(reports)
      .where(eq(reports.userId, userId))
      .orderBy(desc(reports.updatedAt));
  }

  async createReport(report: InsertReport): Promise<Report> {
    const [created] = await db
      .insert(reports)
      .values(report)
      .returning();
    return created;
  }

  async updateReport(id: number, report: Partial<InsertReport>, userId: string): Promise<Report | undefined> {
    const [updated] = await db
      .update(reports)
      .set({ ...report, updatedAt: new Date() })
      .where(and(eq(reports.id, id), eq(reports.userId, userId)))
      .returning();
    return updated;
  }

  async deleteReport(id: number, userId: string): Promise<boolean> {
    const result = await db
      .delete(reports)
      .where(and(eq(reports.id, id), eq(reports.userId, userId)));
    return (result.rowCount || 0) > 0;
  }

  // Export operations
  async getExportJobs(userId: string): Promise<ExportJob[]> {
    return await db
      .select()
      .from(exportJobs)
      .where(eq(exportJobs.userId, userId))
      .orderBy(desc(exportJobs.createdAt));
  }

  async createExportJob(job: InsertExportJob): Promise<ExportJob> {
    const [created] = await db
      .insert(exportJobs)
      .values(job)
      .returning();
    return created;
  }

  async updateExportJob(id: number, updates: Partial<ExportJob>, userId: string): Promise<ExportJob | undefined> {
    const [updated] = await db
      .update(exportJobs)
      .set(updates)
      .where(and(eq(exportJobs.id, id), eq(exportJobs.userId, userId)))
      .returning();
    return updated;
  }

  // Saved searches operations
  async getSavedSearches(userId: string, entityType: string): Promise<SavedSearch[]> {
    return await db
      .select()
      .from(savedSearches)
      .where(and(eq(savedSearches.userId, userId), eq(savedSearches.entityType, entityType)))
      .orderBy(savedSearches.name);
  }

  async createSavedSearch(search: any): Promise<SavedSearch> {
    const [created] = await db
      .insert(savedSearches)
      .values(search)
      .returning();
    return created;
  }

  async deleteSavedSearch(id: number, userId: string): Promise<boolean> {
    const result = await db
      .delete(savedSearches)
      .where(and(eq(savedSearches.id, id), eq(savedSearches.userId, userId)));
    return (result.rowCount || 0) > 0;
  }

  // Advanced analytics operations
  async getSalesAnalytics(userId: string, days: number): Promise<any> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    // Get total revenue and deals closed in period
    const [revenueData] = await db
      .select({
        totalRevenue: sum(deals.value),
        dealsClosed: count(deals.id),
      })
      .from(deals)
      .where(and(
        eq(deals.createdBy, userId),
        eq(deals.stage, "closed-won"),
        gte(deals.createdAt, startDate)
      ));

    // Get conversion rate
    const [totalDeals] = await db
      .select({ count: count() })
      .from(deals)
      .where(and(eq(deals.createdBy, userId), gte(deals.createdAt, startDate)));

    const conversionRate = totalDeals.count > 0 
      ? ((revenueData.dealsClosed || 0) / totalDeals.count * 100)
      : 0;

    // Get average deal size
    const avgDealSize = revenueData.dealsClosed && revenueData.dealsClosed > 0
      ? Number(revenueData.totalRevenue) / revenueData.dealsClosed
      : 0;

    return {
      totalRevenue: Number(revenueData.totalRevenue) || 0,
      dealsClosed: revenueData.dealsClosed || 0,
      conversionRate: Math.round(conversionRate * 100) / 100,
      avgDealSize: Math.round(avgDealSize),
      revenueGrowth: 15, // Placeholder - would calculate from previous period
      dealsGrowth: 20,   // Placeholder - would calculate from previous period
      dealSizeGrowth: 5, // Placeholder - would calculate from previous period
      revenueByMonth: [], // Would implement monthly breakdown
      dealsByStage: [],   // Would implement stage breakdown
    };
  }

  async getCustomerAnalytics(userId: string, days: number): Promise<any> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const [customerData] = await db
      .select({
        totalCustomers: count(),
        newCustomers: count(sql`CASE WHEN ${customers.createdAt} >= ${startDate} THEN 1 END`),
      })
      .from(customers)
      .where(eq(customers.createdBy, userId));

    return {
      totalCustomers: customerData.totalCustomers || 0,
      newCustomers: customerData.newCustomers || 0,
      customerGrowth: 12, // Placeholder
      averageLTV: 25000,  // Placeholder
      customersByMonth: [], // Would implement monthly breakdown
      customersByIndustry: [], // Would implement industry breakdown
    };
  }

  async getPipelineAnalytics(userId: string): Promise<any> {
    return await this.getPipelineData(userId);
  }

  async getActivityAnalytics(userId: string, days: number): Promise<any> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const activitiesByType = await db
      .select({
        type: activities.type,
        count: count(),
      })
      .from(activities)
      .where(and(
        eq(activities.performedBy, userId),
        gte(activities.createdAt, startDate)
      ))
      .groupBy(activities.type);

    return {
      activitiesByType,
    };
  }
}

export const storage = new DatabaseStorage();
